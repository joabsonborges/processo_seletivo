<h1>**Desafio 1**</h1>

><p>Baseado na imagem "bootstrap" crie um proejto</p>
><p>Trabalhe com bootstrap, https://getbootstrap.com/docs/4.3/getting-started/introduction/ e monte uma estrutura html</p> 
><p>Todos os items na imagem são components https://getbootstrap.com/docs/4.3/components</p>


