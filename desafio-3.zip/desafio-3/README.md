<h1>**Desafio 3**</h1>

><p>Elabore um CRUD usando o Laravel, MySql, Bootstrap usando apenas uma classe (Usuário);</p>
><p>A criação da tabela deve ser através de migrations.</p>
><p>Classe; Usuario</p>
><p>Atributos; id, nome, email, senha, dataNascimento</p>
><p>Métodos: criarUsuario(), listarUsuario(), atualizarUsuario(), deletarUsuario()</p>
