<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Usuario;

class UsuarioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $usuarios = Usuario::all();

        return view('usuarios.index', compact('usuarios'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('usuarios.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      $request->validate([
        'usuario_nome'=>'required',
        'usuario_email'=> 'required|integer',
        'share_qty' => 'required|integer'
      ]);
      $usuario = new Usuario([
        'usuario_nome' => $request->get('usuario_nome'),
        'usuario_email'=> $request->get('usuario_email'),
        'usuario_nome' => $request->get('usuario_dataNascimento'),
        'usuario_email'=> $request->get('senha')
        
      ]);
      $usuario->save();
      return redirect('/usuarios')->with('sucesso', 'O Usuario foi adicionado');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $usuario = Usuario::find($id);

        return view('usuarios.edit', compact('usuario'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      $request->validate([
        'usuario_nome'=>'required',
        'usuario_email'=> 'required|integer',
        'usuario_dataNascimento'=>'required',
        'senha'=> 'required|integer'
      ]);

      $usuario = Usuario::find($id);
      $usuario->usuario_nome = $request->get('usuario_nome');
      $usuario->usuario_email = $request->get('usuario_email');
      $usuario->usuario_nome = $request->get('usuario_dataNascimento');
      $usuario->usuario_email = $request->get('senha');
     
      $usuario->save();

      return redirect('/usuarios')->with('sucesso', 'O Usuario foi adicionado');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $usuario = Usuario::find($id);
        $usuario->delete();

      return redirect('/usuarios')->with('sucesso', 'O Usuario foi adicionado');
    }
}
