
<h1>**Desafio 2**</h1>

><h3>**Instruções**</h3>
> <p>- Observe que existe uma estrutura simples de pasta, onde se encrontra um arquivo index.html com uma lista de noticias estaticas.</p>
> <p>- Baseado nessa simples estrutura pastas crie um projeto Laravel e adapte a estrutura de pastas do framework.</p>
> <p>- EndPoint principal: http://www.marcha.cnm.org.br/webservice/noticias</p>
> <p>- Traga de uma forma dinamica a lista de noticias com as informações disponibilizadas através de da API.</p>
> <p>- A previa dessas noticias deverá conter no máximo 300 caracteres.</p>
> <p>- Crei um filtro de noticias atraves do campo de busca. Para pesquisar as noticias, basta usar o parâmetro 'pesquisa' na URL: http://www.marcha.cnm.org.br/webservice/noticias?pesquisa=exemplo</p>
> <p>- Crie uma paginação, o parâmetro da paginação é 'page'. EX: http://www.marcha.cnm.org.br/webservice/noticias?page=3</p>





